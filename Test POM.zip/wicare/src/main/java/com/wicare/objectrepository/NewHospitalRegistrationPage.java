package com.wicare.objectrepository;

import org.apache.poi.hssf.record.RightMarginRecord;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.wicare.geneariclib.Browser;
import com.wicare.geneariclib.Constants;
import com.wicare.geneariclib.Webdrivercommonlib;
/*author Rakesh Malvi
 * since 08 january 2018
 */


public class NewHospitalRegistrationPage extends Webdrivercommonlib
{
	
	@FindBy(xpath="//a[text()='Setup New Hospital or Clinic']")
	private WebElement setupnewhospitalbtn;
	
	@FindBy(xpath="//button[text()='Proceed']")
	private WebElement proceedbtn;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Hospital or Clinic Name']")
	private WebElement hospitalnameedt;
	
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Address']")
	private WebElement addressedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='City']")
	private WebElement cityedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Local Government Area']")
	private WebElement localgovermentareaedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Add Hospital or Clinic Locations']")
	private WebElement hospitallocation1edt;
	
	@FindBy(xpath="//img[@width='35' and @src='/assets/icons/add_icon.png']")
	private WebElement iconbtn1;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Add Hospital or Clinic Locations']")
	private WebElement hospitallocation2edt;
	

	@FindBy(xpath="//img[@width='35' and @src='/assets/icons/add_icon.png']")
	private WebElement iconbtn2;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Add Hospital or Clinic Locations']")
	private WebElement hospitallocation3edt;
	

	@FindBy(xpath="//img[@width='35' and @src='/assets/icons/add_icon.png']")
	private WebElement iconbtn3;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Phone number']")
	private WebElement phonenumberedt;
	
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Confirm phone number']")
	private WebElement confirmphonenumberedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Fax']")
	private WebElement faxedt;
	

	@FindBy(xpath="//button[text()='Next']")
	private WebElement nextbtn;
	
	@FindBy(xpath="//button[text()='Ok']")
	private WebElement okbtn;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='First Name']")
	private WebElement firstnameedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Last Name']")
	private WebElement lastnameedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Email Address']")
	private WebElement emailaddressedt;


	@FindBy(xpath="//input[@type='text' and @placeholder='Username']")
	private WebElement newusernameedt;
	
	@FindBy(xpath="//input[@type='password' and @placeholder='Password']")
	private WebElement newpasswordedt;
	
	@FindBy(xpath="//input[@type='password' and @placeholder='Confirm Password']")
	private WebElement confirmpasswordedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Mobile number']")
	private WebElement mobilenumberedt;

	@FindBy(xpath="//button[text()='Register']")
	private WebElement registerbtn;
	
	public void navigateToNewHospitalRegistrationPage()
	{
		Browser.driver.get(Constants.url);
		windowmaximize();
		waitforpagetoload();
		setupnewhospitalbtn.click();
		proceedbtn.click();
		hospitalnameedt.sendKeys(Constants.hospitalname);
		addressedt.sendKeys(Constants.address);
		cityedt.sendKeys(Constants.city);
		localgovermentareaedt.sendKeys(Constants.localgovermentarea);
		hospitallocation1edt.sendKeys(Constants.hospitallocation1);
		iconbtn1.click();
		hospitallocation2edt.sendKeys(Constants.hospitallocation2);
		iconbtn2.click();
		hospitallocation3edt.sendKeys(Constants.hospitallocation3);
		iconbtn3.click();
		Select state= new Select(Browser.driver.findElement(By.xpath ("//div[@class='form-group']/div/select[@formcontrolname='practice_state']")));
		state.selectByVisibleText("Cross River");
		phonenumberedt.sendKeys(Constants.phonenumber);
		confirmphonenumberedt.sendKeys(Constants.confirmphonenumber);
		faxedt.sendKeys(Constants.fax);
		 nextbtn.click();
		 okbtn.click();
		 firstnameedt.sendKeys(Constants.firstname); 
		 lastnameedt.sendKeys(Constants.lastname);
		 emailaddressedt.sendKeys(Constants.emailaddress);
		 newusernameedt.sendKeys(Constants.newusername);
		 newpasswordedt.sendKeys(Constants.newpassword);
		 confirmpasswordedt.sendKeys(Constants.Confirmpassword);
		 mobilenumberedt.sendKeys(Constants.mobilenumber);
		 Select acesscontrol= new Select(Browser.driver.findElement(By.xpath ("//div[@class='form-group']/div/select[@formcontrolname='role_id']")));
	     acesscontrol.selectByVisibleText("Hospital/Clinic Admin");
		 registerbtn.click();
		 

	}
	
	
}
