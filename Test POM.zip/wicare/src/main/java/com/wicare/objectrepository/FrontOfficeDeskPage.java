package com.wicare.objectrepository;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.wicare.geneariclib.Browser;
import com.wicare.geneariclib.Constants;

/*author Rakesh Malvi
 * since 12 january 2018
 */

public class FrontOfficeDeskPage 
{
	
	@FindBy(xpath="//span[text()=' Front Office Desk']")
	private WebElement frontofficedeskbtn;
	
	@FindBy(xpath="//span[text()=' New Patients Registration ']")
	private WebElement newpatientsregistrationbtn;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='First Name']")
	private WebElement firstnameedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Middle Name']")
	private WebElement middlenameedt;
	
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Last Name']")
	private WebElement lastnameedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='User Name']")
	private WebElement usernameedt;
	
	@FindBy(xpath="//div/p-radiobutton[1]/div/div[2]")
	private WebElement sexradiobtn;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Date of birth']")
	private WebElement dateofbirthbtn;
	
	@FindBy(xpath="//tr/td[3]/a/span[text()='25']")
	private WebElement selectdate;
	
	
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Personal Mobile No.']")
	private WebElement personalmobilenoedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='E-mail']")
	private WebElement emailedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Address']")
	private WebElement addressedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='City']")
	private WebElement cityedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Local Govt. Area']")
	private WebElement localgovtareaedt;
	
	@FindBy(xpath="//input[@formcontrolname='kin_person_name' and @placeholder='Name']")
	private WebElement nameedt;
	
	@FindBy(xpath="//input[@formcontrolname='kin_person_relationship' and @placeholder='Relation']")
	private WebElement relationedt;
	
	
	@FindBy(xpath="//input[@formcontrolname='kin_person_mobile' and @placeholder='Mobile No.']")
	private WebElement mobilenoedt;
	
	@FindBy(xpath="//input[@formcontrolname='kin_person_address' and @placeholder='Address']")
	private WebElement addressforkinpersonedt;
	
	
	@FindBy(xpath="//div/div/div/p-checkbox/div/div[2]")
	private WebElement emergencycontactchkbox;
	
	
	@FindBy(xpath="//button[text()='Save']")
	private WebElement savebtn;
	
	@FindBy(xpath="//p-confirmdialog/div/div[3]/p-footer/div/button[text()='Yes']")
	private WebElement yesbtn;
	
	@FindBy(xpath="//form/div/div[1]/div/input[1]")
	private WebElement paycashradiobtn;
	
	@FindBy(xpath="//form/div/div[2]/div/div/div/input[@type='text' and@ placeholder='Enter Amount']")
	private WebElement enteramountedt;
	
	
	@FindBy(xpath="//div[@id='page-wrapper']/app-new-patient-registration/div[7]/p-dialog/div/div[1]/payment-box/section/div/div/div/form/div/div[3]/div[2]/button")
	private WebElement okbtn;
	
	//p-footer/div/div[2]/button[text()='OK']
	
	
   @FindBy(xpath="//div[@id='page-wrapper']/app-new-patient-registration/div[3]/p-confirmdialog/div/div[3]/p-footer/div/button")
	private WebElement successfullyokbtn;
	
	
	
	

	

	
	 
	public void NewPatientRegistration() throws Exception
	{
		frontofficedeskbtn.click();
		newpatientsregistrationbtn.click();
		firstnameedt.sendKeys(Constants.firstname);
		middlenameedt.sendKeys("Kumar");
		lastnameedt.sendKeys(Constants.lastname);
		usernameedt.sendKeys(Constants.username);
	    Select maritalstatus= new Select(Browser.driver.findElement(By.xpath ("//select[@class='form-control input-field ng-untouched ng-pristine ng-invalid' and @formcontrolname='matrimonial_status']")));
	    maritalstatus.selectByVisibleText("Married");
	    sexradiobtn.click();
	
	    Thread.sleep(3000);
		dateofbirthbtn.click();
		Select selectyear= new Select(Browser.driver.findElement(By.xpath ("//p-calendar/span/div/div/div/select[2]")));
		selectyear.selectByVisibleText("1990");
		
		Thread.sleep(3000);
		Select selectmonth= new Select(Browser.driver.findElement(By.xpath ("//p-calendar/span/div/div/div/select[1]")));
		selectmonth.selectByVisibleText("December");
		
	    selectdate.click();
	
	    Select bloodgroup= new Select(Browser.driver.findElement(By.xpath ("//select[@class='form-control input-field ng-untouched ng-pristine ng-invalid' and @formcontrolname='blood_glucose']")));
	    bloodgroup.selectByVisibleText("B-");
	
	
	    Select paymentoption= new Select(Browser.driver.findElement(By.xpath ("//select[@class='form-control input-field ng-untouched ng-pristine ng-invalid' and @formcontrolname='payment_option']")));
	    paymentoption.selectByVisibleText("Self Pay");
	
	    personalmobilenoedt.sendKeys(Constants.mobilenumber);
	    emailedt.sendKeys(Constants.emailaddress);
	    addressedt.sendKeys(Constants.address);
	    cityedt.sendKeys(Constants.city);
	    localgovtareaedt.sendKeys(Constants.localgovermentarea);
	
	    Select state= new Select(Browser.driver.findElement(By.xpath ("//select[@class='form-control input-field ng-untouched ng-pristine ng-invalid' and @formcontrolname='state']")));
	    state.selectByVisibleText("Delta");
	
	    nameedt.sendKeys(Constants.name);
	    relationedt.sendKeys("Brother");
	    mobilenoedt.sendKeys(Constants.mobilenumber);
	    addressforkinpersonedt.sendKeys(Constants.address);
	    emergencycontactchkbox.click();
	    JavascriptExecutor jse = (JavascriptExecutor)Browser.driver;
	    jse.executeScript("window.scrollBy(0,500)", "");
	    Thread.sleep(2000);
        savebtn.click();
	    yesbtn.click();
	    paycashradiobtn.click();
	    enteramountedt.sendKeys("500");
	    Thread.sleep(5000);
	    okbtn.click();
	    Thread.sleep(5000);
	    
	    String expectedresult=Browser.driver.findElement(By.xpath("//span[contains(text(),'Patient details have been submitted successfully.')]")).getText();
		String actulresult ="Patient details have been submitted successfully.";
	    
	    Assert.assertEquals(actulresult, expectedresult);
	    Thread.sleep(5000);
	    successfullyokbtn.click();
	    
	     }
	
	

}
