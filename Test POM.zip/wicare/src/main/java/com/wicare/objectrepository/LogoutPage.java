package com.wicare.objectrepository;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.wicare.geneariclib.Browser;

/*author Rakesh Malvi
 * since 11 january 2018
 */

public class LogoutPage 
{
	@FindBy(xpath="//a[@class='dropdown-toggle count-info' and @title='Logout']")
	private WebElement logoutbtn;
	
	@FindBy(xpath="//div[@id='page-wrapper']/footer-component/div/p-confirmdialog/div/div[3]/p-footer/div[2]/button")
	private WebElement okbtn;
	
	
	
	public void logout() throws InterruptedException
	{
		logoutbtn.click();
		Thread.sleep(5000);
	    okbtn.click();
	}
	
	
	
}
