package com.wicare.objectrepository;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.wicare.geneariclib.Browser;
import com.wicare.geneariclib.Constants;
import com.wicare.geneariclib.Webdrivercommonlib;

public class AdminControlPanelPage extends Webdrivercommonlib
{
	

	@FindBy(xpath="//span[text()='Manage Practices']")
	private WebElement managepracticesbtn;
	
	
	@FindBy(xpath="//table/tbody/tr[1]/td[5]/span[2]/a")
	private WebElement enablebtn;
	
	@FindBy(xpath="//table/tbody/tr[1]/td[5]/span[1]/a")
	private WebElement deletebtn;
	
	public void enabletohospital() throws Exception
	{
		Browser.driver.get(Constants.adminurl);
		windowmaximize();
		waitforpagetoload();
        managepracticesbtn.click();
		Thread.sleep(5000);
		enablebtn.click();
		Thread.sleep(5000);
		Alert alert=Browser.driver.switchTo().alert();
		alert.accept();
		Thread.sleep(2000);
		alert.accept();
	}
	
	public void deletetohospital() throws Exception
	{
		Browser.driver.get(Constants.adminurl);
		windowmaximize();
		waitforpagetoload();
        managepracticesbtn.click();
		Thread.sleep(5000);
		deletebtn.click();
		Thread.sleep(5000);
		Alert alert=Browser.driver.switchTo().alert();
		alert.accept();
		Thread.sleep(2000);
		alert.accept();
	}
	
	
	
}
