package com.wicare.objectrepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.wicare.geneariclib.Browser;
import com.wicare.geneariclib.Constants;

public class WardManagementPage 
{
	@FindBy(xpath="//span[text()=' Front Office Desk']")
	private WebElement frontofficedeskbtn;
	

	@FindBy(xpath="//a[@href='/front-desk-office/ward-management']")
	private WebElement wardmanagementbtn;
	
	@FindBy(xpath="//img[@width='32' and @src='./assets/img/add_icon.png']")
	private WebElement addiconbtn;
	
	@FindBy(id="ward_name")
	private WebElement wardnameetd;
	
	@FindBy(id="no_of_beds")
	private WebElement noofbedetd;
	
	@FindBy(xpath="//button[text()='Save']")
	private WebElement savebtn;
	
	@FindBy(xpath="//table/tbody/tr/td[5]/a[1]/img")
	private WebElement editiconbtn;
	
	
	@FindBy(xpath="//div/div/div/form/div[4]/button[text()='Update']")
	private WebElement updatebtn;
	
	
	public void wardmanagement()
	{
		frontofficedeskbtn.click();
		wardmanagementbtn.click();
		addiconbtn.click();
		wardnameetd.sendKeys(Constants.wardname);
		Select wardtype= new Select(Browser.driver.findElement(By.xpath ("//select[@class='form-control input-field ng-untouched ng-pristine ng-invalid' and @formcontrolname='ward_type']")));
	    wardtype.selectByVisibleText("ICU Ward");
	    noofbedetd.sendKeys(Constants.noofbed);
	    savebtn.click();
	}
	
	public void editwardmanagement() throws InterruptedException
	{
		frontofficedeskbtn.click();
		wardmanagementbtn.click();
		Thread.sleep(5000);
		editiconbtn.click();
		Select editwardtype= new Select(Browser.driver.findElement(By.xpath ("//app-add-ward-management/section/div/div/div/form/div[2]/select")));
	    editwardtype.selectByVisibleText("AC Ward");
	    updatebtn.click();
		
	}

}
