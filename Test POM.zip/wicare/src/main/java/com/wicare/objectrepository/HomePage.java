package com.wicare.objectrepository;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.wicare.geneariclib.Browser;
import com.wicare.geneariclib.Constants;
/*author Rakesh Malvi
 * since 12 january 2018
 */
public class HomePage 
{
	@FindBy(xpath="//p[text()='Create and manage wiCare Users ']")
	private WebElement createandmanageuserslnk;
	
	
	@FindBy(xpath="//img[@width='42' and @src='./assets/img/add_icon.png']")
	private WebElement addinguserplussign;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='First Name']")
	private WebElement firstnameedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Last Name']")
	private WebElement lastnameedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Email Address']")
	private WebElement emailaddressedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Username']")
	private WebElement newusernameedt;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Mobile Number']")
	private WebElement mobilenumberedt;
	
	@FindBy(xpath="//div[@style='width: 100%;']/label[text()='Access Control']/following-sibling::div[1]")
	private WebElement accesscontrol;
	
	@FindBy(xpath="//div/p-dropdown/div/div[4]/div/ul/li[6]/span[text()='Physician/M.D/D.O']")
	private WebElement selectphysician;
	
	@FindBy(xpath="//div/p-dropdown/div/div[4]/div/ul/li[2]/span[text()='Nurse']")
	private WebElement selectnurse;
	
	@FindBy(xpath="//div/p-dropdown/div/div[4]/div/ul/li[3]/span[text()='Front User']")
	private WebElement selectfrontuser;
	
	@FindBy(xpath="//div/p-dropdown/div/div[4]/div/ul/li[5]/span[text()='Hospital/Clinic Admin']")
	private WebElement selecthospitaladmin;
	
	@FindBy(xpath="//div/p-dropdown/div/div[4]/div/ul/li[7]/span[text()='Physician Assistant']")
	private WebElement selectphysicianassistant;
	
	@FindBy(xpath="//button[text()='Add User']")
	private WebElement adduserbtn;
	
	@FindBy(xpath="//div[@id='page-wrapper']/ng-component/ng-component/app-add-wicare/div[4]/p-confirmdialog/div/div[3]/p-footer/div/button")
	private WebElement Successfullyokbtn;
	
	
	@FindBy(xpath="//button[text()='Search']")
	private WebElement searchbtn;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Email ID']")
	private WebElement emailidedt;
	

	@FindBy(xpath="//label[contains(text(),'wiCare User Manager')]")
	private WebElement backbtn;
	
	
	@FindBy(xpath="//tr[1]/td[3]/a[contains(text(),'@yopmail.com')]")
	private WebElement editUser;
	
	@FindBy(xpath="//img[@height='42' and @src='./assets/img/add_icon.png']")
	private WebElement addpersonaldetailicon;
	
	@FindBy(xpath="//*[@id='about']")
	private WebElement aboutedt;
	
	@FindBy(xpath="//*[@id='education']")
	private WebElement educationedt;
	
	@FindBy(xpath="//*[@id='expertise']")
	private WebElement expertiseedt;
	
	@FindBy(xpath="//*[@id='certification']")
	private WebElement certificationedt;
	
	@FindBy(xpath="//button[text()='Save']")
	private WebElement savebtn;
	

	@FindBy(xpath="//tr[4]/td[8]/div/div/p-checkbox/div")
	private WebElement activecheckbox;
	
	
	
	
	
	public void AddPhysician() throws Exception
	{
		createandmanageuserslnk.click();
		addinguserplussign.click();
		Thread.sleep(2000);
		firstnameedt.sendKeys(Constants.firstname);
		lastnameedt.sendKeys(Constants.lastname);
		emailaddressedt.sendKeys(Constants.emailaddress);
		newusernameedt.sendKeys(Constants.newusername);
		mobilenumberedt.sendKeys(Constants.mobilenumber);
		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor)Browser.driver;
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(5000);
		accesscontrol.click();
		selectphysician.click();
		JavascriptExecutor jsd = (JavascriptExecutor)Browser.driver;
		jsd.executeScript("window.scrollBy(0,500)", "");
		adduserbtn.click();
		  
		String actulconfirmationmsg= "User information is successfully saved and login information has been sent to the email address provided during user registration.";
		String expectedresult=Browser.driver.findElement(By.xpath("//span[contains(text(),'User information is successfully saved and login information has been sent to the email address provided during user registration.')]")).getText();
		Assert.assertEquals(actulconfirmationmsg, expectedresult);
		Successfullyokbtn.click();
	}
	
	public void AddNurse() throws Exception
	{
		createandmanageuserslnk.click();
		addinguserplussign.click();
		Thread.sleep(2000);
		firstnameedt.sendKeys(Constants.firstname);
		lastnameedt.sendKeys(Constants.lastname);
		emailaddressedt.sendKeys(Constants.emailaddress);
		newusernameedt.sendKeys(Constants.newusername);
		mobilenumberedt.sendKeys(Constants.mobilenumber);
		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor)Browser.driver;
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(5000);
		accesscontrol.click();
		selectnurse.click();
		JavascriptExecutor jsd = (JavascriptExecutor)Browser.driver;
		jsd.executeScript("window.scrollBy(0,500)", "");
		adduserbtn.click();
		  
		String actulconfirmationmsg= "User information is successfully saved and login information has been sent to the email address provided during user registration.";
		String expectedresult=Browser.driver.findElement(By.xpath("//span[contains(text(),'User information is successfully saved and login information has been sent to the email address provided during user registration.')]")).getText();
		Assert.assertEquals(actulconfirmationmsg, expectedresult);
		Successfullyokbtn.click();
	}
	
	public void AddFrontUser() throws Exception
	{
		createandmanageuserslnk.click();
		addinguserplussign.click();
		Thread.sleep(2000);
		firstnameedt.sendKeys(Constants.firstname);
		lastnameedt.sendKeys(Constants.lastname);
		emailaddressedt.sendKeys(Constants.emailaddress);
		newusernameedt.sendKeys(Constants.newusername);
		mobilenumberedt.sendKeys(Constants.mobilenumber);
		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor)Browser.driver;
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(5000);
		accesscontrol.click();
		selectfrontuser.click();
		JavascriptExecutor jsd = (JavascriptExecutor)Browser.driver;
		jsd.executeScript("window.scrollBy(0,500)", "");
		adduserbtn.click();
		  
		String actulconfirmationmsg= "User information is successfully saved and login information has been sent to the email address provided during user registration.";
		String expectedresult=Browser.driver.findElement(By.xpath("//span[contains(text(),'User information is successfully saved and login information has been sent to the email address provided during user registration.')]")).getText();
		Assert.assertEquals(actulconfirmationmsg, expectedresult);
		Successfullyokbtn.click();
	}
	
	public void AddHospitaladmin() throws Exception
	{
		createandmanageuserslnk.click();
		addinguserplussign.click();
		Thread.sleep(2000);
		firstnameedt.sendKeys(Constants.firstname);
		lastnameedt.sendKeys(Constants.lastname);
		emailaddressedt.sendKeys(Constants.emailaddress);
		newusernameedt.sendKeys(Constants.newusername);
		mobilenumberedt.sendKeys(Constants.mobilenumber);
		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor)Browser.driver;
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(5000);
		accesscontrol.click();
		selecthospitaladmin.click();
		JavascriptExecutor jsd = (JavascriptExecutor)Browser.driver;
		jsd.executeScript("window.scrollBy(0,500)", "");
		adduserbtn.click();
		  
		String actulconfirmationmsg= "User information is successfully saved and login information has been sent to the email address provided during user registration.";
		String expectedresult=Browser.driver.findElement(By.xpath("//span[contains(text(),'User information is successfully saved and login information has been sent to the email address provided during user registration.')]")).getText();
		Assert.assertEquals(actulconfirmationmsg, expectedresult);
		Successfullyokbtn.click();
	}
	
	
	public void AddPhysicianassistant() throws Exception
	{
		createandmanageuserslnk.click();
		addinguserplussign.click();
		Thread.sleep(2000);
		firstnameedt.sendKeys(Constants.firstname);
		lastnameedt.sendKeys(Constants.lastname);
		emailaddressedt.sendKeys(Constants.emailaddress);
		newusernameedt.sendKeys(Constants.newusername);
		mobilenumberedt.sendKeys(Constants.mobilenumber);
		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor)Browser.driver;
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(5000);
		accesscontrol.click();
		selectphysician.click();
		JavascriptExecutor jsd = (JavascriptExecutor)Browser.driver;
		jsd.executeScript("window.scrollBy(0,500)", "");
		adduserbtn.click();
		  
		String actulconfirmationmsg= "User information is successfully saved and login information has been sent to the email address provided during user registration.";
		String expectedresult=Browser.driver.findElement(By.xpath("//span[contains(text(),'User information is successfully saved and login information has been sent to the email address provided during user registration.')]")).getText();
		Assert.assertEquals(actulconfirmationmsg, expectedresult);
		Successfullyokbtn.click();
	}
	
	
	
	public void searchuserbyfirstname() throws InterruptedException
	{
		createandmanageuserslnk.click();
		firstnameedt.sendKeys(Constants.firstname);
		searchbtn.click();
		Thread.sleep(5000);
       backbtn.click();
		
	}
	
	public void searchuserbylasttname() throws InterruptedException
	{
		createandmanageuserslnk.click();
		lastnameedt.sendKeys(Constants.lastname);
		searchbtn.click();
		Thread.sleep(5000);
		backbtn.click();
	}
	
	public void searchuserbyemailaddress() throws InterruptedException
	{
		createandmanageuserslnk.click();
		emailidedt.sendKeys(Constants.emailaddress);
		searchbtn.click();
		Thread.sleep(5000);
		backbtn.click();
	}
	
	
	public void edituserdetail()
	{
		createandmanageuserslnk.click();
		editUser.click();
		mobilenumberedt.sendKeys("1234567890");
		lastnameedt.sendKeys("Verma");
		
		
   }
	
	public void personaldetails()
	{
		addpersonaldetailicon.click();
		aboutedt.sendKeys("Add some information in about text box ");
		educationedt.sendKeys("Add some Education information in text box ");
		expertiseedt.sendKeys("Add some Expertise information in text box");
		certificationedt.sendKeys("Add some Certification information in text box");
		JavascriptExecutor jse = (JavascriptExecutor)Browser.driver;
		jse.executeScript("window.scrollBy(0,500)", "");
		savebtn.click();
		
		
		}
	
	public void selecttheuserforinactive()
	{
		createandmanageuserslnk.click();
		activecheckbox.click();
		
	}
		
		
		
	}
	
	


