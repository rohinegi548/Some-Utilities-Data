package com.wicare.geneariclib;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.imageio.stream.FileImageInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/*author Rakesh Malvi
 * since 08 january 2018
 */

public class Excellib 
{
	String filepath="";
	
	public String getexceldata(String sheetname, int rownum,int colnum) throws Throwable
	{
		FileInputStream fis= new FileInputStream(filepath);
		Workbook wb= WorkbookFactory.create(fis);
		Sheet sh= wb.getSheet(sheetname);
		Row row=sh.getRow(rownum);
		String data= row.getCell(colnum).getStringCellValue();
		return data;
	}
	
	public void setexceldata(String sheetname, int rownum,int colnum,String data) throws Throwable
	{
		FileInputStream fis= new FileInputStream(filepath);
		Workbook wb=WorkbookFactory.create(fis);
		Sheet sh=wb.getSheet(sheetname);
		Row row=sh.getRow(rownum);
		Cell cell=row.createCell(colnum);
		cell.setCellValue(data);
		
		FileOutputStream fos=new FileOutputStream(filepath);
		wb.write(fos);
		wb.close();
	}
}
