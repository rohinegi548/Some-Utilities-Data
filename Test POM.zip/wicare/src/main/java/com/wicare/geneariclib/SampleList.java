package com.wicare.geneariclib;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.Port.Info;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.steadystate.css.util.Output;


/*author Rakesh Malvi
 * since 08 january 2018
 */



public abstract class SampleList implements ITestListener
{

	public void onTestFailure(ITestResult t) 
	{
		String failedtestname=t.getMethod().getMethodName();
		
		EventFiringWebDriver edriver=new EventFiringWebDriver(Browser.driver);
		File srcfile= edriver.getScreenshotAs(OutputType.FILE);
		File dstfile= new File(System.getProperty("user.dir")+"//Screenshot//"+"failedtestname"+".png");
		
		try
		{
			FileUtils.copyFile(srcfile, dstfile);
		}
		catch( IOException e)
		{
			
			e.printStackTrace();
		}
	}

	

} 
