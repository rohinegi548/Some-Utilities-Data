package com.wicare.geneariclib;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/*author Rakesh Malvi
 * since 08 january 2018
 */

public class Browser 
{
	 public static WebDriver driver;
	 
	 public static WebDriver getbrowser()
	 {
		 if(Constants.browsername.equals("firefox"))
		 {	
			 System.setProperty("webdriver.firefox.marionette", "E:\\DayUsers\\RakeshM\\Software\\geckodriver-v0.17.0-win64\\geckodriver.exe");
			 driver=new FirefoxDriver();
		 }
		 else if(Constants.browsername.equals("chrome"))
		 {
			 System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rakesh M\\Downloads\\chromedriver_win32\\chromedriver.exe");
			 driver= new ChromeDriver();
		 }
		 else if(Constants.browsername.equals("edge"))
		 {
			System.setProperty("webdriver.edge.driver", "C:\\Users\\RakeshM\\Downloads");
			driver= new EdgeDriver();
		 }
		return driver;
		 
	 }

}
