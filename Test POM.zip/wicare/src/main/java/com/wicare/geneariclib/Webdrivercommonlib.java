package com.wicare.geneariclib;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/*author Rakesh Malvi
 * since 08 january 2018
 */

public class Webdrivercommonlib 
{
	public void waitforpagetoload()
	{
		Browser.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	public void waitforelement(WebElement element)
	{
		WebDriverWait wait= new WebDriverWait(Browser.driver, 30);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	public void windowmaximize()
	{
		Browser.driver.manage().window().maximize();
	}
	

}
