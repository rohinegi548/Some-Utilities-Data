package com.wicare.geneariclib;
/*author Rakesh Malvi
 * since 08 january 2018
 */
public interface Constants 
{
    String url="http://52.34.207.5:5053/";
    String adminurl="http://52.34.207.5:5053/admin";
	String newusername="virat001";
	String newpassword="Password@rm01";
	String Confirmpassword="Password@rm01";
	String browsername="chrome";
	String selectpractice="A";
	String hospitalname="smartData";
	String address="Nagpur";
	String city="Nagpur";
	String localgovermentarea="Nagpur";
	String hospitallocation1="Nagpur";
	String hospitallocation2="Bhopal";
	String hospitallocation3="Indore";
	String phonenumber="9876543210";
	String confirmphonenumber="9876543210";
	String fax="987654";
	String firstname="Raman";
	String lastname="Singh";
	String emailaddress="raman@yopmail.com";
	String mobilenumber="2365287418";
	String username="aman001";
	String password="Password@rm01";
	String name="Rohit";
	String wardname="Ward01";
	String noofbed="21";
	
	
}
