package com.wiCare;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.wicare.geneariclib.Browser;
import com.wicare.objectrepository.FrontOfficeDeskPage;
import com.wicare.objectrepository.HomePage;
import com.wicare.objectrepository.LoginPage;
import com.wicare.objectrepository.LogoutPage;

public class HomeTest 
{
	
	WebDriver driver;
	LoginPage page;
	HomePage homepage;
	LogoutPage logoutpage;

	@BeforeClass
	  public void beforeClass() 
	{
	     /*launch browser*/
	   driver=Browser.getbrowser();
	   page=PageFactory.initElements(Browser.driver, LoginPage.class);
	   homepage=PageFactory.initElements(Browser.driver, HomePage.class);
	   logoutpage=PageFactory.initElements(driver,LogoutPage.class);
	  
	}
	
	
	@Test
	public void logintest() throws Exception
	{
		
		/*login to app  */
		
		Reporter.log("Login to application");
		page.loginToApp();
	     
	     
	     homepage.AddPhysician();
	     
	     
	     
	      /* homepage.searchuserbyfirstname();
	       homepage.searchuserbylasttname();
	       homepage.searchuserbyemailaddress();
	       homepage.edituserdetail();
	       homepage.personaldetails();
	       homepage.selecttheuserforinactive();*/
	       
	   //    logoutpage.logout();
	

}
	@AfterClass
	 public void afterClass() 
		{
		   // Browser.driver.close();
		  
		}
	
}