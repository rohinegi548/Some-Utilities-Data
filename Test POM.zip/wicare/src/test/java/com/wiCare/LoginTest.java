package com.wiCare;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.gargoylesoftware.htmlunit.javascript.host.file.File;
import com.wicare.objectrepository.HomePage;
import com.wicare.objectrepository.LoginPage;
import com.wicare.objectrepository.LogoutPage;
import com.wicare.objectrepository.NewHospitalRegistrationPage;
import com.wicare.geneariclib.Browser;
/*author Rakesh Malvi
 * since 09 january 2018
 */
public class LoginTest 
{ 
	WebDriver driver;
	LoginPage page;
	LogoutPage Lgpage;
	
	@BeforeClass
	  public void beforeClass() 
	{
	     /*launch browser*/
	   driver=Browser.getbrowser();
	   page=PageFactory.initElements(Browser.driver, LoginPage.class);
	   Lgpage=PageFactory.initElements(driver,LogoutPage.class);
	  
	}
	
	@Test
	public void logintest() throws Exception
	{

		/*login to app  */
		
       Reporter.log("Login to application");
		
	    page.loginToApp();
		
		
	/*	Navigate to reset your username page
		page.navigateToResetYourusernamePage();
		
		Navigate to reset your password page
		page.navigateToResetYourpasswordPage();
		
		Create a new hospital and clinic registration 
		page.navigateToNewHospitalRegistrationPage();*/
		
		Lgpage.logout();

   }
	@AfterClass
	 public void afterClass() 
		{
		    Browser.driver.close();
		  
		}


}

