package com.wiCare;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.wicare.geneariclib.Browser;
import com.wicare.objectrepository.FrontOfficeDeskPage;
import com.wicare.objectrepository.LoginPage;
import com.wicare.objectrepository.LogoutPage;
import com.wicare.objectrepository.WardManagementPage;

/*author Rakesh Malvi
 * since 12 january 2018
 */

public class NewPatientRegistrationTest 
{
	/*Create object of Generic Library*/
	WebDriver driver;
	LoginPage page;
	FrontOfficeDeskPage FODpage;
	LogoutPage Lgpage;
	WardManagementPage wmpage;
	
	@BeforeClass
	public void Configbeforeclass()
	{
		/*launch browser*/
		 Reporter.log("launch browser");
		 driver=Browser.getbrowser();
	     page=PageFactory.initElements(driver, LoginPage.class);
	     FODpage=PageFactory.initElements(driver,FrontOfficeDeskPage.class);
         Lgpage=PageFactory.initElements(driver,LogoutPage.class);
		 wmpage=PageFactory.initElements(driver,WardManagementPage.class);
	}
	@Test
	public void createnewpatientregistration() throws Exception
	{  /*login to Application */
	   Reporter.log("Login to Application");
		page.loginToApp();
		
		
		/*Navigate to New patient Registration page*/	
	    // FODpage.NewPatientRegistration();
		// wmpage.wardmanagement();
		 wmpage.editwardmanagement();
	     Reporter.log("Logout to Application");
	 // Lgpage.logout();
		
		
	}
	
	@AfterClass
	 public void afterClass() 
		{
		
		//    Browser.driver.close();
		  
		}
	
	
	

}
