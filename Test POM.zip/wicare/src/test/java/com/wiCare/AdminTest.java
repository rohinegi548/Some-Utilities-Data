package com.wiCare;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.wicare.geneariclib.Browser;
import com.wicare.objectrepository.AdminControlPanelPage;
import com.wicare.objectrepository.HomePage;
import com.wicare.objectrepository.LoginPage;
import com.wicare.objectrepository.LogoutPage;

public class AdminTest 
{
	WebDriver driver;
	AdminControlPanelPage acppage;
	
	@BeforeClass
	  public void beforeClass() 
	{
		
	     /*launch browser*/
	   driver=Browser.getbrowser();
	   
	   acppage=PageFactory.initElements(driver,AdminControlPanelPage.class); 
	   
	 }
	
	@Test
	public void admintest() throws Exception 
	{
		//acppage.enabletohospital();
		acppage.deletetohospital();
	}
	
	@AfterClass
	 public void afterClass() 
		{
		//   Browser.driver.close();
		  
		}
	

}
