package com.wiCare;
/*author Rakesh Malvi
 * since 08 january 2018
 */


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.wicare.objectrepository.LogoutPage;
import com.wicare.objectrepository.NewHospitalRegistrationPage;
import com.wicare.geneariclib.Browser;

/*author Rakesh Malvi
 * since 11 january 2018
 */

public class NewHospitalRegistrationTest 
{
	/*Create object of Generic Library*/
	WebDriver driver;
	NewHospitalRegistrationPage NHRpage ;
	
	
	@BeforeClass
	  public void ConfigbeforeClass() 
	{
		/*launch browser*/
		 Reporter.log("launch browser");
		 driver=Browser.getbrowser();
	     NHRpage=PageFactory.initElements(Browser.driver, NewHospitalRegistrationPage.class);
	     
	}
	
	@Test
	public void hospitalregistrationtest()
	{
		
		/*Create a new hospital and clinic registration*/
		Reporter.log("Create a new hospital and clinic registration");
		NHRpage.navigateToNewHospitalRegistrationPage();
		Reporter.log("");
		 
	 }
	
	
	@AfterClass
	 public void afterClass() 
		{
		
		    Browser.driver.close();
		  
		}
}
