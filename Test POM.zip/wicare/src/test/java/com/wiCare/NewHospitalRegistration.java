package com.wiCare;

/*author Rakesh Malvi
 * since 08 january 2018
 */

import java.util.concurrent.TimeUnit;

import org.eclipse.jetty.util.log.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class NewHospitalRegistration 
{
	public static void main(String[] args) throws InterruptedException 
	{
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rakesh M\\Downloads\\chromedriver_win32\\chromedriver.exe");
	 
	WebDriver driver= new ChromeDriver();
    driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	driver.get("http://52.34.207.5:5053/");
	driver.findElement(By.xpath("//a[text()='Setup New Hospital or Clinic']")).click();
	driver.findElement(By.xpath("//button[text()='Proceed']")).click();
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='Hospital or Clinic Name']")).sendKeys("smartData");
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='Address']")).sendKeys("Nagpur");
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='City']")).sendKeys("Nagpur");
    driver.findElement(By.xpath ("//input[@type='text' and @placeholder='Local Government Area']")).sendKeys("Nagpur");
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='Add Hospital or Clinic Locations']")).sendKeys("Nagpur");
	driver.findElement(By.xpath ("//img[@width='35' and @src='/assets/icons/add_icon.png']")).click();
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='Add Hospital or Clinic Locations']")).sendKeys("Bhopal");
	driver.findElement(By.xpath ("//img[@width='35' and @src='/assets/icons/add_icon.png']")).click();
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='Add Hospital or Clinic Locations']")).sendKeys("Indore");
	driver.findElement(By.xpath ("//img[@width='35' and @src='/assets/icons/add_icon.png']")).click();
	Thread.sleep(5000);
	Select state= new Select(driver.findElement(By.xpath ("//div[@class='form-group']/div/select[@formcontrolname='practice_state']")));
	state.selectByVisibleText("Cross River");
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='Phone number']")).sendKeys("9876543210");
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='Confirm phone number']")).sendKeys("9876543210");
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='Fax']")).sendKeys("987654");
	driver.findElement(By.xpath("//button[text()='Next']")).click();
	driver.findElement(By.xpath("//button[text()='Ok']")).click();
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='First Name']")).sendKeys("Virat");
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='Last Name']")).sendKeys("Singh");
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='Email Address']")).sendKeys("virat@yopmail.com");
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='Username']")).sendKeys("virat001");
	driver.findElement(By.xpath ("//input[@type='password' and @placeholder='Password']")).sendKeys("Password@rm01");
	driver.findElement(By.xpath ("//input[@type='password' and @placeholder='Confirm Password']")).sendKeys("Password@rm01");
	driver.findElement(By.xpath ("//input[@type='text' and @placeholder='Mobile number']")).sendKeys("2365287418");
	
	/*Select acesscontrol= new Select(driver.findElement(By.xpath ("//div[@class='form-group']/div/select[@formcontrolname='role_id']")));
	acesscontrol.selectByVisibleText("Hospital/Clinic Admin");*/
	driver.findElement(By.xpath("//button[text()='Register']")).click();
	//driver.close();
	}
	
	
	
	//div[@class='form-group']/div/select[@formcontrolname='practice_state']
}
