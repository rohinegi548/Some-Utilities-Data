package TenanantTests;

import org.testng.annotations.Test;

import TenantUtilities.PropertyUtil;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Step;

import org.testng.annotations.BeforeMethod;

import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

@Epic("Regression Test")
@Feature("Client Registration functionality")


public class TM_CreateClient {

	public static WebDriver driver;
	
  
	 @BeforeMethod(description="Setting up browser to execute test")
	  @Step("Logging in system and clicking on create new client link")
  public void beforeMethod(Method method) throws InterruptedException {
	  
	    System.out.println("Executing: "+method.getName());
	    System.setProperty("webdriver.chrome.driver", PropertyUtil.getProperty("driverPath"));
	    driver= new ChromeDriver();
	    driver.get(PropertyUtil.getProperty("baseurl"));
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    
	    //Login to access the tenant home page
	    driver.findElement(By.xpath("//input[@name='email']")).sendKeys(PropertyUtil.getProperty("tmuser"));
	    driver.findElement(By.xpath("//input[@name='password']")).sendKeys(PropertyUtil.getProperty("tmpass"));
	    driver.findElement(By.xpath("//div//button[contains(text(),'Log In')]")).click();
		Thread.sleep(5000);
		  
		// finding create new client button
	    WebElement Create_client=driver.findElement(By.xpath("//ul[contains(@class,'menu')]/li/a[starts-with(text(),'Clients')]"));
	    Create_client.click();
		Thread.sleep(1000);
		
	  
  }

  
  
  @Test(description="Verifying if user is able to create a new client") 
  //verifying if user is able to create a new client
  public void Is_Able_To_Create_Client() throws InterruptedException{
	  
	  driver.findElement(By.xpath("//a[contains(@class,'button') and contains(text(),'Add Client')]")).click();
	  Thread.sleep(3000);
	  
	  //selecting office under which we are going to create client
	  Select OfficeSelectDrpDwn=new Select(driver.findElement(By.xpath("//div/select[contains(@name,'office')]")));
	  OfficeSelectDrpDwn.selectByVisibleText(PropertyUtil.getProperty("officename"));
	  Thread.sleep(3000);
	  
	  
	  WebElement ClientName=driver.findElement(By.xpath("//input[contains(@placeholder,'A name for your client') and @type='text']"));
	  ClientName.sendKeys(PropertyUtil.getProperty("clientname")); Thread.sleep(3000);
	  
	  WebElement subdomain=driver.findElement(By.xpath("//input[contains(@name,'url_fragment') and @type='text']"));
	  subdomain.sendKeys(PropertyUtil.getProperty("clientsubdomain")); Thread.sleep(3000);
	  
	  
	  //Adding user for this office_client: first/last name, email, password, role
	  WebElement fname = driver.findElement(By.xpath("//*[contains(@class,'tenants-users-fields')]//input[contains(@name,'first_name')]"));
	  fname.sendKeys(PropertyUtil.getProperty("clientfname")); Thread.sleep(3000);
	  
	  WebElement lname = driver.findElement(By.xpath("//*[contains(@class,'tenants-users-fields')]//input[contains(@name,'last_name')]"));
	  lname.sendKeys(PropertyUtil.getProperty("clientlname")); Thread.sleep(3000);
	  
	  WebElement email = driver.findElement(By.xpath("//*[contains(@class,'tenants-users-fields')]//input[contains(@name,'email')]"));
	  email.sendKeys(PropertyUtil.getProperty("clientemail")); Thread.sleep(3000);
	  
	  Select roleSelectionDrpDwn=new Select(driver.findElement(By.xpath("//*[contains(@class,'tenants-users-fields')]//select[contains(@name,'role')]")));
	  roleSelectionDrpDwn.selectByVisibleText(PropertyUtil.getProperty("clientrole")); Thread.sleep(3000);
	  
	  driver.findElement(By.xpath("//*[contains(@class,'button') and contains(text(),'Create')]")).click();
	  Thread.sleep(3000);
	  
	  driver.navigate().refresh();
	  
	  Thread.sleep(5000);
	  
	  Assert.assertTrue(
			  driver.findElement(By.xpath("//td/span[contains(text(),'"+PropertyUtil.getProperty("clientname")+"')]")).isDisplayed(),
			  "Client: "+PropertyUtil.getProperty("clientname")+
			  " under Office: "+PropertyUtil.getProperty("officename")+" did not create, Failing Test!\n\n"
			  );
	  
	  System.out.println("Client: "+PropertyUtil.getProperty("clientname")+
			  " under Office: "+PropertyUtil.getProperty("officename")+" has been created, Passing Test!\n\n");
	  
  }
  

  
  @AfterMethod(description="Closing session")
  public void afterMethod() {
	  
	  
	  if(driver!=null)
			driver.quit();
}
	  
  }


