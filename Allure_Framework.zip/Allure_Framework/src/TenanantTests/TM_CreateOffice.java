package TenanantTests;

import org.testng.annotations.Test;

import TenantUtilities.PropertyUtil;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Step;

import org.testng.annotations.BeforeMethod;

import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

@Epic("Regression Test")
@Feature("Office Registration functionality")

public class TM_CreateOffice {

	public static WebDriver driver;
	
  
  @BeforeMethod(description="Setting up browser to execute test")
  @Step("Logging in system and clicking on create new office link")
  public void beforeMethod(Method method) throws InterruptedException {
	  
	    System.out.println("Executing: "+method.getName());
	    System.setProperty("webdriver.chrome.driver", PropertyUtil.getProperty("driverPath"));
	    driver= new ChromeDriver();
	    driver.get(PropertyUtil.getProperty("baseurl"));
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    
	    //Login to access the tenant home page
	    driver.findElement(By.xpath("//input[@name='email']")).sendKeys(PropertyUtil.getProperty("tmuser"));
	    driver.findElement(By.xpath("//input[@name='password']")).sendKeys(PropertyUtil.getProperty("tmpass"));
	    driver.findElement(By.xpath("//div//button[contains(text(),'Log In')]")).click();
		Thread.sleep(5000);
		  
		// finding create new office button
	    WebElement Create_office=driver.findElement(By.xpath("//ul[contains(@class,'menu')]/li/a[starts-with(text(),'Offices')]"));
		Create_office.click();
		Thread.sleep(1000);
		
	  
  }

  
  
  @Test(description="Verifying if user is able to create a new office")
  //verifying if user is able to create a new office
  public void Is_Able_To_Create_Office() throws InterruptedException{
	  
	  driver.findElement(By.xpath("//a[contains(@class,'button') and contains(text(),'Add Offic')]")).click();
	  Thread.sleep(3000);
	  
	  WebElement officeName=driver.findElement(By.xpath("//input[contains(@placeholder,'Office name') and @type='text']"));
	  officeName.sendKeys(PropertyUtil.getProperty("officename")); Thread.sleep(3000);
	  
	  //Adding user for this office: first/last name, email, password, role
	  WebElement fname = driver.findElement(By.xpath("//*[contains(@class,'tenants-users-fields')]//input[contains(@name,'first_name')]"));
	  fname.sendKeys(PropertyUtil.getProperty("officefname")); Thread.sleep(3000);
	  
	  WebElement lname = driver.findElement(By.xpath("//*[contains(@class,'tenants-users-fields')]//input[contains(@name,'last_name')]"));
	  lname.sendKeys(PropertyUtil.getProperty("officelname")); Thread.sleep(3000);
	  
	  WebElement email = driver.findElement(By.xpath("//*[contains(@class,'tenants-users-fields')]//input[contains(@name,'email')]"));
	  email.sendKeys(PropertyUtil.getProperty("officeemail")); Thread.sleep(3000);
	  
	  WebElement password = driver.findElement(By.xpath("//*[contains(@class,'tenants-users-fields')]//input[contains(@name,'password')]"));
	  password.sendKeys(PropertyUtil.getProperty("officepassword")); Thread.sleep(3000);
	  
	  Select roleSelectionDrpDwn=new Select(driver.findElement(By.xpath("//*[contains(@class,'tenants-users-fields')]//select[contains(@name,'role')]")));
	  roleSelectionDrpDwn.selectByVisibleText(PropertyUtil.getProperty("officerole")); Thread.sleep(3000);
	  
	  driver.findElement(By.xpath("//*[contains(@class,'button') and contains(text(),'Create')]")).click();
	  Thread.sleep(3000);
	  
	  driver.navigate().refresh();
	  
	  Thread.sleep(5000);
	  
	  Assert.assertTrue(
			  driver.findElement(By.xpath("//td/span[contains(text(),'"+PropertyUtil.getProperty("officename")+"')]")).isDisplayed(),
			  "Office: "+PropertyUtil.getProperty("officename")+" did not create, Failing Test!\n\n"
			  );
	  
	  System.out.println("Office: "+PropertyUtil.getProperty("officename")+" has been created, Passing Test!\n\n");
	  
  }
  
  
 
  @AfterMethod(description="Closing session")
  public void afterMethod() {
	  
	  
	  if(driver!=null)
			driver.quit();
}
	  
  }


