package TenanantTests;

import org.testng.annotations.Test;

import TenantUtilities.PropertyUtil;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;

import org.testng.annotations.BeforeMethod;

import java.io.File;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;

@Epic("Regression Test")
@Feature("Login Page Functions")

public class TM_Login {
	
public static WebDriver driver;
 
  @BeforeMethod(description="Setting up browser to execute test")
  public void beforeMethod(Method method) {
	  
	    System.out.println("Executing: "+method.getName());
	    System.setProperty("webdriver.chrome.driver", PropertyUtil.getProperty("driverPath"));
	    driver = new ChromeDriver();
	    driver.get(PropertyUtil.getProperty("baseurl"));
	   // driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    
  }

  
  @Test(description="Verifying if Login page is available")
  public void Is_Tenant_login_screen_available() throws InterruptedException{ //TMA login screen
	  
	  WebElement logintxt=driver.findElement(By.xpath("//div//button[contains(text(),'Log In')]"));
	  Thread.sleep(2000);
	  String loginbtn=logintxt.getText();
	  Assert.assertEquals(loginbtn, "Log In", "Tenant Manager Login screen is not available, Failing Test!");
	  System.out.println("Tenant Manager Login screen is available, Passing Test!"); 
	  
  }
  
  
  
  @Test(description="Verifying if Login page title is as expected")
  public void Is_Login_Title_As_Expected() throws InterruptedException{ //verifying title of login page
	  
	  String loginTitle=driver.getTitle();
	  Thread.sleep(2000);
	  Assert.assertEquals(loginTitle, "Log in", "Title is: "+loginTitle+" which is not expected, Failing Test!");
	  System.out.println("Title is: "+loginTitle+" which is expected, Passing Test!");  
  }
  
  
  
  @Test(description="Verifying body text on the Login page")
  public void Is_Admin_Body_Text_As_Expected() throws InterruptedException{ //verifying admin body text
	  
	  String bodyText = driver.findElement(By.xpath("//p[starts-with(text(),'This site is for use by admin')]")).getText();
	  Thread.sleep(2000);
	  Assert.assertTrue(
			  bodyText.contains("This site is for use by administrative staff only."
			  + " If you have arrived here for learning, please contact your learning administrator"), 
			  "Expected body text doesn't found on page, Failing Test!");
	  
	  System.out.println("Expected body text found on page, Passing Test!");
  }
  
  
  
  @Test(description="Verifying is Login disabled w/o entering credentials")
  public void IsLoginDisabledWithoutEnteringCredentials() throws InterruptedException{ //verifying login button is disabled w/o entering credentials
	  
	  driver.findElement(By.xpath("//input[@name='email']")).clear(); //clearing content of username field if any
	  driver.findElement(By.xpath("//input[@name='password']")).clear(); //clearing content of password field if any
	  WebElement loginbtn=driver.findElement(By.xpath("//div//button[contains(text(),'Log In')]"));
	  Thread.sleep(2000);
	  Assert.assertFalse((loginbtn.isEnabled()),"Login is still enabled even if credentials not entered, Failing Test!");
	  System.out.println("Login is disabled without entering credentials, Passing Test!");
  }
  
  
  
  @Test(description="Verifying is Login enabled after entering credentials")
  public void IsLoginEnabledAfterEnteringCredentials() throws InterruptedException{ //verifying login button is enabled after entering login credentials
	  
	  driver.findElement(By.xpath("//input[@name='email']")).sendKeys(PropertyUtil.getProperty("tmuser"));
	  Thread.sleep(3000);
	  driver.findElement(By.xpath("//input[@name='password']")).sendKeys(PropertyUtil.getProperty("tmpass"));
	  Thread.sleep(3000);
	  WebElement loginbtn=driver.findElement(By.xpath("//div//button[contains(text(),'Log In')]"));
	  Assert.assertTrue((loginbtn.isEnabled()), "Login is not enabled even after entering credentials, Failing Test!");
	  Thread.sleep(3000);
	  System.out.println("Login is enabled after entering credentials, Passing Test!");
  }
  
  
  
  @AfterMethod(description="Closing session")
  public void afterMethod(ITestResult result) {
	  
	  if(ITestResult.FAILURE==result.getStatus()){
			try{
				// To create reference of TakesScreenshot
				TakesScreenshot screenshot=(TakesScreenshot)driver;
				// Call method to capture screenshot
				File src=screenshot.getScreenshotAs(OutputType.FILE);
				// Copy files to specific location 
				// result.getName() will return name of test case so that screenshot name will be same as test case name
				FileUtils.copyFile(src, new File("Screenshots\\"+result.getName()+".png"));
				System.out.println("Successfully captured screenshot for failed TestCase: "+result.getName());
				
			}catch (Exception e){
				
				System.out.println("Exception while taking screenshot "+e.getMessage());
			} 
	}
		driver.quit();
		
	}

}
