package stepdefs;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class CRMLoginStepdef {
	
	WebDriver driver;
	
	
	
	@Given("^user login into the system$")
	public void user_login_into_the_system(io.cucumber.datatable.DataTable loginDetails) {
		
		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://www.freecrm.com");
		List<List<String>> loginDtl=loginDetails.cells();
		driver.findElement(By.name("username")).sendKeys(loginDtl.get(0).get(0));
		driver.findElement(By.name("password")).sendKeys(loginDtl.get(0).get(1));
		
		WebElement loginBtn=driver.findElement(By.xpath("//input[@value='Login']"));
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", loginBtn);
	   
	}

	@Then("^moves to New Contact$")
	public void moves_to_New_Contact() {
		
		driver.switchTo().frame("mainpanel");
		WebElement CONTACTS=driver.findElement(By.xpath("//*[@href='https://www.freecrm.com/system/index.cfm?action=contact']"));
		Actions builder= new Actions(driver);
		builder.moveToElement(CONTACTS)
		.moveToElement(driver.findElement(By.xpath("//li/a[@title='New Contact']")))
		.click().build().perform();
		
	    
	}

	@SuppressWarnings("deprecation")
	@Then("^enters contact details$")
	public void enters_contact_details(io.cucumber.datatable.DataTable Contacts) {
		
		List<List<String>> ContactDtl=Contacts.cells();
		driver.findElement(By.id("first_name")).sendKeys(ContactDtl.get(0).get(0));
		driver.findElement(By.id("surname")).sendKeys(ContactDtl.get(0).get(1));
		driver.findElement(By.id("email")).sendKeys(ContactDtl.get(0).get(2));
		
		driver.findElement(By.xpath("//*[@value='Load From Company']/following::input[1]")).click();
		
		driver.findElement(By.xpath("//li/a[@title='Contacts']")).click();
		
		Assert.assertEquals(ContactDtl.get(0).get(2),
				driver.findElement(By.xpath("//td/a[contains(text(),'"+ContactDtl.get(0).get(2)+"')]")).getText());
	    
	}



	@Then("^close the browser$")
	public void close_the_browser() {
	   
		driver.quit();
	}
	
/*	@Given("^user is already on Login Page$")
	public void user_is_already_on_Login_Page() {
		
		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://www.freecrm.com");
	}

	@SuppressWarnings("deprecation")
	@When("^title of login page is Free CRM$")
	public void title_of_login_page_is_Free_CRM() {
		
		Assert.assertEquals("Free CRM software in the cloud powers sales and customer service", driver.getTitle());
	   
	}

	@Then("^user enters \"(.*)\" and \"(.*)\"$")
	public void user_enters_username_and_password(String user, String pass) {
		
		driver.findElement(By.name("username")).sendKeys(user);
		driver.findElement(By.name("password")).sendKeys(pass);
	   
	}

	@Then("^user clicks on login button$")
	public void user_clicks_on_login_button() {
		
		WebElement loginBtn=driver.findElement(By.xpath("//input[@value='Login']"));
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", loginBtn);
	}
	

	@SuppressWarnings("deprecation")
	@Then("^user is on home page$")
	public void user_is_on_home_page() {
		
		Assert.assertEquals("CRMPRO", driver.getTitle());
	   
	}

	@Then("^Close the browser$")
	public void close_the_browser() {
		
		driver.quit();
	   
	}*/
	
	

}
